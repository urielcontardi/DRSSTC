# ARCSTRIKE — enclosure v1 mechanical concept

Assembly based on the supplied PCB STEP and heatsink/C14 STLs. This is a review
and fit-prototype design. Coil dimensions and thermal mounting require actual
parts and measurements before final printing.

## Files

- `exports/case-viewer.html`: offline Canvas 2D viewer with rotation, zoom,
  part selection, and exploded view. No WebGL is needed; a static preview remains
  available when scripts are blocked.
- `exports/case-preview.png`: assembled enclosure preview.
- `exports/ARCSTRIKE-case-v1-CONCEPT.step`: complete CAD assembly.
- `exports/01_lower_tray.stl`: ventilated lower tray.
- `exports/02_upper_sleeve.stl`: removable upper side walls.
- `exports/03_C14_inlet_plate.stl`: replaceable inlet adapter.
- `exports/04_structural_lid.stl`: lid with a coil-support interface.
- `exports/05_coil_support_PLACEHOLDER.stl`: provisional support, dimensions unverified.
- `exports/06_separate_feet.stl`: four separate feet.
- `exports/verification.json`: dimensions and geometric intersection checks.
- `reference/`: supplied reference geometry.

## Proposed dimensions and assembly

The PCB is 100 × 100 mm, centered at XY=(50,50). The heatsink is
100 × 100 × 30 mm with a 5 mm base and eighteen 2 mm fins. The nineteen STL
blocks were reconstructed at their original dimensions and joined into a valid
solid without smoothing. The flat face points toward the IGBTs and the fins
point down. XY center offset is zero.

The enclosure is 130 × 130 mm. Its body is 93 mm high, or 97 mm with feet.
The provisional upper support adds 28 mm. The illustrative tube is excluded
from enclosure height.

Datum: PCB bottom Z=0, KiCad component datum Z=1.595 mm. IGBT metal face
Z=-5.005 mm. A nominal 0.3 mm thermal interface places the heatsink top at
Z=-5.305 mm and bottom at Z=-35.305 mm. Verify the actual interface thickness.

Three existing mounting holes are used: (6,94), (94,94), and (94,6), with
88 mm spacing. J2/PE at (6,6) stays accessible for earth connection rather than
serving as a fourth plastic support. A relief clears terminals and copper near
(94,6).

The C14 inlet is on the rear wall (positive Y), aligned with J1. Supplied STL:
approximately 50 × 22 mm flange, 26 × 18 mm rear body, and 3.2 mm mounting
holes spaced 42 mm apart. Proposed opening: 26.6 × 18.6 mm (0.3 mm per-side
clearance), with 3.4 mm printed holes. Check the actual inlet, terminals, and
cable connectors.

The C14 STL housing is inconsistent when converted to BRep. The HTML shows
the exact original mesh. The STEP uses a simplified analytical housing and
six valid contact solids reconstructed from the mesh; this is not exact
manufacturer CAD.

The fiber window is 16 × 14 mm on the left wall, centered at Y=28.35 mm and
crossing the tray/sleeve seam. It provides receiver access rather than a printed
optical coupling. Check its position and clearance against the actual plug;
the receiver is recessed from the wall.

The lid has four M4 holes on an 80 mm square and two 6 mm primary-wire passages.
Provisional support: 32 mm secondary tube, 32.6 mm socket, and primary former
with 54 mm inside diameter and 24 mm height. These are placeholders, not selected
electrical dimensions. Actual tube retention, wire gauge, turn count, coil
spacing, and high-voltage terminal position/shape remain unspecified.

## Printing and outstanding checks

Walls are 3 mm thick and the lid is 4 mm. Choose tray and sleeve orientation
in the slicer. Support arms, heatsink rails, and upper sockets may need local
print supports. Separate feet avoid a broad bridge below the floor. Place the
C14 adapter's largest flat face on the bed.

The 2.8 mm pilot holes for M3 joints require a printed test coupon. There are
no CAD threads or dimensioned insert sockets. Select fasteners/inserts and
verify lid strength using the actual coil mass. Do not print the placeholder
coil support as a final component.

The tray supports the heatsink at the fin ends, with nominal 0.4 mm lateral
clearance. Vertical retention and IGBT-to-heatsink fasteners remain undesigned.
No mounting holes were invented in the supplied heatsink.

Printing material, temperatures, ventilation, insulation, earthing, and electrical
clearances require verification on the actual assembly. No thermal or safety
rating is assigned. Check the purchased IGBT package against the
[onsemi datasheet](https://www.onsemi.com/download/data-sheet/pdf/fga60n65smd-d.pdf).
Existing IGBT models use provisional lead bends and heights.

## Regeneration

Extract the package, edit `case-v1/parameters.json`, and run from its parent:

```sh
uv run --with cadquery python case-v1/build.py
python3 case-v1/build_viewer.py
node case-v1/render_preview.cjs inside
```

The CAD builder checks enclosure intersections with the PCB/components,
heatsink, C14, and other printed parts. Absence of geometric intersection does
not validate assembly, tool access, heating, or insulation. The CAD builder
also supplies the mesh data needed to regenerate the viewer; Node.js renders
its PNG preview.
